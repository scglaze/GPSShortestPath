import java.util.Set;

public class Dijkstra {
	
	static int totalCost;
	
	public Dijkstra() {
		
	}
	
	public static Path shortestPath(Vertex source, Vertex destination) {
		
		Graph graph = new Graph("MapInformationXY.txt");
		
		if (source.equals(destination)) {
			return new Path(source);
		}
		
		HeapPriorityQueue<Path> paths = new HeapPriorityQueue<Path>();
		
		// Initially adding the neighbors of the source vertex
		Set<Edge> neighboringEdges = graph.getNeighboringEdges(source);
		if (neighboringEdges != null) {
			for (Edge neighbor : neighboringEdges) {
				Path temp = new Path(source);
				temp.append(neighbor.getDestination(), neighbor.getTimeCost(), neighbor.getDistanceCost());
				paths.add(temp);
			}
		} else {
			return null;
		}
		
		// searching the graph and find the shortest path from the source Vertex to the destination Vertex.
		while (paths.size() > 0) {
			// Removing the path at the front of the Queue
			Path p = paths.remove();
						
			//System.out.println(p.toString());
			
			// Checking if this Path is a desired path
			if (p.getDestination().equals(destination)) {
				return p;
			}
			
			// If not, add all possible paths that come from p to paths.
			for (Edge neighbor : graph.getNeighboringEdges(p.getDestination())) {
				Path path = new Path(source);
				for (int i = 1; i < p.length(); i++) {
					path.append(p.get(i));
				}
				// Making sure that the path doesn't already contain the vertex.
				// This stops an infinite loop.
				if (!(path.containsVertex(neighbor.getDestination()))) {
					path.append(neighbor.getDestination());
					path.setDistanceCost(p.distanceCost() + neighbor.distanceCost);
					path.setTimeCost(p.timeCost() + neighbor.timeCost);
					paths.add(path);
				}
			}			
		}
		
		// If code reaches this point then no possible path was found between the two vertices
		return null;
	}
	
}


public class Driver {

	public static void main(String[] args) { 
		UI frame = new UI(); 
		frame.setVisible(true);
	}	
	
}
